import asyncio

from aiogram import Bot, Dispatcher
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.types import *

from DataBase.database import DB
from Parser.parserRUZ import RuzParser

bot = Bot(token="6143815192:AAEbY3ktbCmhCPWkTEIqVkqB3MUaRehM1Ck")
dp = Dispatcher(bot=bot, storage=MemoryStorage())
db = DB()
parser = RuzParser()
themes = ['Важно', 'Спорт', 'Обученние', 'Анонсы', 'Абитуриентам', 'События', 'Стажировки и парктика',
          'Конкурсы', 'Поздравления', 'Наука', 'Студенческая жизнь']

about = [['Декан Факультета информационных технологий и анализа больших данных', 'Феклин Вадим Геннадьевич',
           'Кандидат физико-математических наук, доцент.', '•\tМосква, 4-й Вешняковский пр-д, 4, корп. 1, каб. 1201.',
           '•\tТел.: +7 (499) 503-4700', '•\tПриемные часы: по предварительному согласованию.'],
          ['Помощник декана:', 'Наталья Юрьевна Чулина', 'NYChulina@fa.ru',
           'Москва, 4-й Вешняковский пр-д, 4, корп. 1, каб.  1201, тел. +7 (499) 503-4700'],
          ['Первый заместитель декана факультета информационных технологий и анализа больших данных',
           'Ирина Александровна Александрова', '•\tМосква, 4-й Вешняковский пр-д, 4, корп. 1, каб. 1214',
           '•\tТел.: +7 (499) 553-1449*4739', '•\tE-mail: IAleksandrova@fa.ru',
           '•\tПриемные часы: понедельник, 14.00-16.00; пятница, 14.00-15.00'],
          ['Главный специалист:', 'Мадина Магомедовна Айбазова', 'MMAjbazova@fa.ru',
           'Москва, 4-й Вешняковский пр-д, 4, корп. 1, каб.  1214, тел. +7 (499) 553-1449*6586'],
          ['Заместитель декана факультета информационных технологий и анализа больших данных по учебной работе',
           'Михаил Викторович Коротеев', '•\tМосква, 4-й Вешняковский пр-д, 4, корп. 1, каб. 1204',
           '•\tТел.: +7 (499) 503-4721*6592', '•\tE-mail: MVKoroteev@fa.ru',
           '•\tПриемные часы: среда, четверг, 14.00-16.00'],
          ['Главный специалист:', 'Лейла Камилевна Степанова', 'LKStepanova@fa.ru',
           'Москва, 4-й Вешняковский пр-д, 4, корп. 1, каб. 1204, тел. +7 (499) 503-4721*6592'],
          ['Заместитель декана факультета информационных технологий и анализа больших данных '
           'по дополнительному профессиональному образованию и международному сотрудничеству',
           'Мирзоян Мариам Валериковна', '•\tМосква, 4-й Вешняковский пр-д, 4, корп. 1, каб. 1205',
           '•\tТел.: +7 (499) 503-4721*6576', '•\tE-mail: MVMirzoyan@fa.ru',
           '•\tПриемные часы: понедельник, вторник, 14.00-16.00'],
          ['Главный специалист:', 'Кадохова Виктория Александровна', 'VAKadokhova@fa.ru',
           'Москва, 4-й Вешняковский пр-д, 4, корп. 1, каб. 1205, тел. +7 (499) 503-4721*6002'],
          ['Заместитель декана факультета информационных технологий и анализа больших данных по научной работе',
           'Расул Ахматович Кочкаров', '•\tМосква, 4-й Вешняковский пр-д, 4, корп. 1, каб. 1212',
           '•\tТел.: +7 (495) 249-5200*5200', '•\tE-mail: rkochkarov@fa.ru', '•\tПриемные часы: среда, 11.00-14.00'],
          ['Главный специалист:', 'Екатерина Сергеевна Бодренко', 'LESBodrenko@fa.ru',
           'Москва, 4-й Вешняковский пр-д, 4, корп. 1, каб. 1212, тел. +7 (499) 503-4702*4715'],
          ['Заместитель декана факультета информационных технологий и анализа больших данных '
           'по воспитательной работе и связям с выпускниками', 'Андрей Иванович Гайдамака',
           '•\tМосква, 4-й Вешняковский пр-д, 4, корп. 1, каб. 1211', '•\tТел.: +7 (499) 503-4720',
           '•\tE-mail: AIGajdamaka@fa.ru', '•\tПриемные часы: среда, четверг, 14.00-16.00'],
          ['Менеджер факультета информационных технологий и анализа больших данных', 'Тамара Владимировна Звягинцева',
           '•\tМосква, 4-й Вешняковский пр-д, 4, корп. 1, каб.  1213', '•\tТел.: +7 (499) 503-4721*4743',
           '•\tE-mail: kb235zvy@fa.ru', '•\tПриемные часы: понедельник-пятница, 10.00-12.00'],
          ['Главный специалист:', 'Ольга Викторовна Петрова',
           'Куратор подготовки аспирантов и студентов магистратуры (все направления подготовки),',
           'а также студентов очно-заочной формы обучения (направление подготовки «Прикладная информатика»)',
           'OPetrova@fa.ru', 'Москва, 4-й Вешняковский пр-д, 4, корп. 1, каб. 1213, тел. +7 (499) 503-4721*4744'],
          ['Главный специалист:', 'Ирина Владимировна Баскова', 'Куратор подготовки студентов бакалавриата',
           '(направление подготовки «Прикладная математика и информатика»)', 'IVBaskova@fa.ru',
           'Москва, 4-й Вешняковский пр-д, 4, корп. 1, каб. 1213, тел. +7 (499) 503-4721*4742'],
          ['Главный специалист:', 'Мария Александровна Литвина', 'Куратор подготовки студентов бакалавриата',
           '(направление подготовки «Прикладная информатика»)', 'MALitvina@fa.ru',
           'Москва, 4-й Вешняковский пр-д, 4, корп. 1, каб. 1213, тел. +7 (499) 503-4721*4745'],
          ['Главный специалист:', 'Фаризат Заурбековна Губачикова ', 'Куратор подготовки студентов бакалавриата',
           '(направление подготовки «Информационная безопасность»)', 'FZGubachikova@fa.ru',
           'Москва, 4-й Вешняковский пр-д, 4, корп. 1, каб. 1213, тел. +7 (499) 503-4721*6001'],
          ['Главный специалист:', 'Полина Петровна Парфенова', 'Куратор подготовки студентов бакалавриата',
           '(направление подготовки «Бизнес-информатика»)', 'PPVoronina@fa.ru',
           'Москва, 4-й Вешняковский пр-д, 4, корп. 1, каб. 1213 тел. +7 (499) 503-4721*6587']
          ]

# студент Расписание Новости
student_keyboard = ReplyKeyboardMarkup().row("Расписание", "Новости").row("Курсовые", "ВКР").row("О факультете")
teacher_keyboard = ReplyKeyboardMarkup().row("Расписание", "Новости"). \
    row("Написать новость").row("Темы").row("О факультете")


def generate_choose_theme_keyboard(user_id):
    themes_keyboard = InlineKeyboardMarkup()

    for i in themes:
        if user_id not in user_info.keys():
            themes_keyboard.add(InlineKeyboardButton(text=f"❌ {i}", callback_data=f"themes_{i}_{user_id}"))
        else:
            themes_keyboard.add(InlineKeyboardButton(text=f"❌ {i}" if i not in user_info[user_id] else f"✔️ {i}",
                                                     callback_data=f"themes_{i}_{user_id}"))

    themes_keyboard.add(InlineKeyboardButton(text="Закончить", callback_data=f"themes_end"))

    return themes_keyboard


def generate_tags(tag_list: list) -> str:
    tags = ""

    for i in tag_list:
        tags += f"#{i}, "

    tags.rstrip(", ")

    return tags


user_info = {
    # from_user.id : choosedthemes
}


class Choose(StatesGroup):
    get_type = State()


class StudentRegistration(StatesGroup):
    fio = State()
    group = State()
    stud_bilet = State()
    themes = State()


class TeacherRegistration(StatesGroup):
    fio = State()
    themes = State()


class Schedule(StatesGroup):
    when = State()
    date = State()
    result = State()


class News(StatesGroup):
    title = State()
    text = State()
    image = State()
    themes = State()
    sure = State()
    result = State()
    edit = State()
    edited = State()


class SeeNews(StatesGroup):
    show = State()


@dp.message_handler(commands=['keyboard'])
async def keyboard(message: Message):
    await message.answer("rewrwe", reply_markup=teacher_keyboard)


@dp.message_handler(commands=['start'])
async def start(message: Message, state: FSMContext):
    await message.answer("Добро пожаловать в бота!")

    if not db.check_user(message.from_user.id):
        await message.answer("Выберите кто Вы!", reply_markup=ReplyKeyboardMarkup().
                             row("Преподаватель", "Студент"))

        await Choose.get_type.set()
    else:
        await message.answer("Вы уже зарегистрированны!")


# ---------------------------
# Информация о факультете
# ---------------------------

def generate_info(id):
    msg = ""
    info = about[id]

    msg += f"<b>{info[0]}</b>\n"
    msg += f"<i>{info[1]}</i>\n\n"

    for i in info[2::]:
        msg += f"{i}\n"

    print(msg)

    return msg

@dp.message_handler(text="О факультете")
async def facult_info(message: Message):
    for i in range(len(about)):
        await message.answer(generate_info(i), parse_mode="HTML")


# ---------------------------
# Занятие тем (ВКР / Курсовые)
# ---------------------------

def generate_keyboard_vkr():
    keyboard = InlineKeyboardMarkup()

    for i in db.get_all_teachers():
        keyboard.row(InlineKeyboardButton(text=f"{i[0]} {i[1][0]}.{i[2][0]}.",
                                          callback_data=f"{i[3]}"))

    keyboard.row(InlineKeyboardButton(text="Выйти", callback_data="exit"))

    return keyboard


def generate_keyboard_themes_vkr(teacher_id):
    keyboard = InlineKeyboardMarkup()

    for i in db.get_vkr_by_teacher_id(teacher_id):
        mark = "❌" if i[1] is not None else "✔️"
        keyboard.row(InlineKeyboardButton(text=f"{mark} {i[0]}", callback_data=f"{i[0].replace(' ', '_')};{mark}"))

    keyboard.row(InlineKeyboardButton(text="Выйти", callback_data="exit"))

    return keyboard


def generate_keyboard_themes_curs(teacher_id):
    keyboard = InlineKeyboardMarkup()

    for i in db.get_curs_by_teacher_id(teacher_id):
        mark = "❌" if i[1] is not None else "✔️"
        keyboard.row(InlineKeyboardButton(text=f"{mark} {i[0]}", callback_data=f"{i[0].replace(' ', '_')};{mark}"))

    keyboard.row(InlineKeyboardButton(text="Выйти", callback_data="exit"))

    return keyboard


class ChooseNauchVKR(StatesGroup):
    choose = State()
    get_theme = State()


@dp.message_handler(text="ВКР")
async def student_vkr(message: Message):
    if db.check_has_vkr(message.from_user.id):
        await message.answer("У Вас уже есть тема ВКР")

        return
    if db.get_user_type(message.from_user.id):
        await message.answer("Выберите научного руководителя!", reply_markup=generate_keyboard_vkr())

        await ChooseNauchVKR.choose.set()


@dp.callback_query_handler(state=ChooseNauchVKR.choose)
async def student_vkr_choose(call: CallbackQuery, state: FSMContext):
    if call.data == "exit":
        await call.message.delete()

        await call.message.answer("Вышел", reply_markup=student_keyboard)

        await state.finish()
    teacher_info = db.get_teacher_info(call.data)
    await call.message.edit_text(text=f"Научный руководитель: {teacher_info[1]} {teacher_info[2]} {teacher_info[3]}",
                                 reply_markup=generate_keyboard_themes_vkr(call.data))

    await ChooseNauchVKR.get_theme.set()


@dp.callback_query_handler(state=ChooseNauchVKR.get_theme)
async def student_vkr_get_theme(call: CallbackQuery, state: FSMContext):
    if call.data == "exit":
        await call.message.edit_text(text="Выберите научного руководителя!", reply_markup=generate_keyboard_vkr())

        await ChooseNauchVKR.choose.set()

        return

    if call.data.split("_")[1] == "❌":
        await call.answer(text="Эта тема занята!")

        return

    teacher_id = db.set_vkr(call.from_user.id, call.data.split(";")[0].replace("_", " "))

    await call.message.delete()

    await call.message.answer(f'Тема выбрана!\n\n[Научный руководитель](tg://user?id={teacher_id})',
                              reply_markup=student_keyboard, parse_mode="MarkDown")

    await state.finish()


class ChooseNauchCurs(StatesGroup):
    choose = State()
    get_theme = State()


@dp.message_handler(text="Курсовые")
async def student_curs(message: Message):
    if db.check_has_curs(message.from_user.id):
        await message.answer("У Вас уже есть тема Курсовой")

        return
    if db.get_user_type(message.from_user.id):
        await message.answer("Выберите научного руководителя!", reply_markup=generate_keyboard_vkr())

        await ChooseNauchCurs.choose.set()


@dp.callback_query_handler(state=ChooseNauchCurs.choose)
async def student_curs_choose(call: CallbackQuery, state: FSMContext):
    if call.data == "exit":
        await call.message.delete()

        await call.message.answer("Вышел", reply_markup=student_keyboard)

        await state.finish()

        return
    teacher_info = db.get_teacher_info(call.data)
    await call.message.edit_text(text=f"Научный руководитель: {teacher_info[1]} {teacher_info[2]} {teacher_info[3]}",
                                 reply_markup=generate_keyboard_themes_curs(call.data))

    await ChooseNauchCurs.get_theme.set()


@dp.callback_query_handler(state=ChooseNauchCurs.get_theme)
async def student_curs_get_theme(call: CallbackQuery, state: FSMContext):
    if call.data == "exit":
        await call.message.edit_text(text="Выберите научного руководителя!",
                                     reply_markup=generate_keyboard_vkr())

        await ChooseNauchCurs.choose.set()

        return

    if call.data.split("_")[1] == "❌":
        await call.answer(text="Эта тема занята!")

        return

    teacher_id = db.set_curs(call.from_user.id, call.data.split("_")[0].replace("_", " "))

    await call.message.delete()

    await call.message.answer(f"Тема выбрана!\n\n[Научный руководитель](tg://user?id={teacher_id})",
                              reply_markup=student_keyboard, parse_mode="MarkDown")

    await state.finish()


# ---------------------------
# Добавление тем (ВКР / Курсовые)
# ---------------------------

class Topics(StatesGroup):
    choose = State()


class VKRTopics(StatesGroup):
    set_theme = State()
    add_theme = State()
    sure = State()


class CursTopics(StatesGroup):
    set_theme = State()
    add_theme = State()
    sure = State()


@dp.message_handler(text="Темы")
async def topic(message: Message):
    if not db.get_user_type(message.from_user.id):
        await message.answer("Выберите где хотите редактировать темы",
                             reply_markup=ReplyKeyboardMarkup().row("ВКР", "Курсовые"))

        await Topics.choose.set()


@dp.message_handler(state=Topics.choose)
async def topic_choose(message: Message, state: FSMContext):
    if message.text == "ВКР":
        await message.answer("Выберите действие!",
                             reply_markup=ReplyKeyboardMarkup().row("Добавить тему", "Посмотреть существующие").
                             add("Выйти"))

        await VKRTopics.set_theme.set()
    elif message.text == "Курсовые":
        await message.answer("Выберите действие!",
                             reply_markup=ReplyKeyboardMarkup().row("Добавить тему", "Посмотреть существующие").
                             add("Выйти"))

        await CursTopics.set_theme.set()


def format_tuple(tpl: tuple) -> str:
    if len(tpl) == 0:
        return "*Пока нет тем*"
    StringResult = ""
    for i in tpl:
        mark = "❌" if i[1] is not None else "✔️"
        StringResult += f"*{mark} {i[0]}*\n"

    return StringResult


@dp.message_handler(state=VKRTopics.set_theme)
async def vkr_topic_set(message: Message, state: FSMContext):
    if message.text == "Добавить тему":
        await message.answer("Введите название темы!", reply_markup=ReplyKeyboardRemove())
        await VKRTopics.add_theme.set()

    elif message.text == "Посмотреть существующие":
        await message.answer(f"Ваши текущие темы:\n\n{format_tuple(db.get_vkr_by_teacher_id(message.from_user.id))}",
                             parse_mode="MARKDOWN")

    elif message.text == "Выйти":
        await state.finish()
        await message.answer("Выход произведён", reply_markup=teacher_keyboard)


@dp.message_handler(state=VKRTopics.add_theme)
async def vkr_add_topic(message: Message, state: FSMContext):
    await state.update_data({"theme": message.text})

    await message.answer(f"Введённая Вами тема верна?\n\n`{message.text}`",
                         reply_markup=InlineKeyboardMarkup().
                         row(InlineKeyboardButton(text="Да", callback_data="yes")).
                         row(InlineKeyboardButton(text="Нет", callback_data="no")), parse_mode="MARKDOWN")

    await VKRTopics.sure.set()


@dp.callback_query_handler(state=VKRTopics.sure)
async def vkr_sure(call: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    if call.data == "yes":
        db.add_vkr(call.from_user.id, data["theme"])
        await call.message.answer("Тема успешно добавлена!")

        await call.message.answer("Выберите действие!",
                                  reply_markup=ReplyKeyboardMarkup().row("Добавить тему", "Посмотреть существующие").
                                  add("Выйти"))

        await VKRTopics.set_theme.set()
    elif call.data == "no":
        await call.message.answer("Напишите тему ещё раз!")

        await VKRTopics.add_theme.set()


@dp.message_handler(state=CursTopics.set_theme)
async def curs_topic_set(message: Message, state: FSMContext):
    if message.text == "Добавить тему":
        await message.answer("Введите название темы!", reply_markup=ReplyKeyboardRemove())
        await CursTopics.add_theme.set()

    elif message.text == "Посмотреть существующие":
        await message.answer(f"Ваши текущие темы:\n\n{format_tuple(db.get_curs_by_teacher_id(message.from_user.id))}",
                             parse_mode="MARKDOWN")

    elif message.text == "Выйти":
        await state.finish()
        await message.answer("Выход произведён", reply_markup=teacher_keyboard)


@dp.message_handler(state=CursTopics.add_theme)
async def curs_add_topic(message: Message, state: FSMContext):
    await state.update_data({"theme": message.text})

    await message.answer(f"Введённая Вами тема верна?\n\n`{message.text}`",
                         reply_markup=InlineKeyboardMarkup().
                         row(InlineKeyboardButton(text="Да", callback_data="yes")).
                         row(InlineKeyboardButton(text="Нет", callback_data="no")), parse_mode="MARKDOWN")

    await CursTopics.sure.set()


@dp.callback_query_handler(state=CursTopics.sure)
async def curs_sure(call: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    if call.data == "yes":
        db.add_curs(call.from_user.id, data["theme"])
        await call.message.answer("Тема успешно добавлена!")

        await call.message.answer("Выберите действие!",
                                  reply_markup=ReplyKeyboardMarkup().row("Добавить тему", "Посмотреть существующие").
                                  add("Выйти"))

        await CursTopics.set_theme.set()
    elif call.data == "no":
        await call.message.answer("Напишите тему ещё раз!")

        await CursTopics.add_theme.set()


# ---------------------------
# Просмотр новостей
# ---------------------------

user_news = {}
to_navigate_1 = InlineKeyboardMarkup().row(InlineKeyboardButton(text="->", callback_data="next")). \
    row(InlineKeyboardButton(text="Выйти", callback_data="quit"))
to_navigate_2 = InlineKeyboardMarkup().row(InlineKeyboardButton(text="<-", callback_data="prev"),
                                           InlineKeyboardButton(text="->", callback_data="next")). \
    row(InlineKeyboardButton(text="Выйти", callback_data="quit"))
to_navigate_3 = InlineKeyboardMarkup().row(InlineKeyboardButton(text="<-", callback_data="prev")). \
    row(InlineKeyboardButton(text="Выйти", callback_data="quit"))

user_news_len = {}


@dp.message_handler(text="Новости")
async def see_news(message: Message):
    news_info = db.get_news_by_tags(message.from_user.id)

    if len(news_info) == 0:
        await message.answer("Для Вас пока нет новостей!")

        return

    await message.answer("Новости по Вашим темам!", reply_markup=ReplyKeyboardRemove())

    if len(news_info) == 1:
        msg = await message.answer_photo(photo=news_info[0][5], caption=f"`{news_info[0][2]}`\n\n"
                                                                        f"{news_info[0][3]}\n\n"
                                                                        f"{news_info[0][4]}", parse_mode="MARKDOWN")
    else:
        msg = await message.answer_photo(photo=news_info[0][5], caption=f"`{news_info[0][2]}`\n\n"
                                                                        f"{news_info[0][3]}\n\n"
                                                                        f"{news_info[0][4]}", parse_mode="MARKDOWN",
                                         reply_markup=to_navigate_1)
        await SeeNews.show.set()

    user_news[msg.message_id] = 0
    user_news_len[msg.message_id] = len(db.get_news_by_tags(message.from_user.id))


@dp.callback_query_handler(state=SeeNews.show)
async def news(call: CallbackQuery, state: FSMContext):
    if call.data == "quit":
        await call.message.delete()
        del user_news[call.message.message_id]

        await call.message.answer("Готово!", reply_markup=student_keyboard if db.get_user_type(call.from_user.id) else
        teacher_keyboard)

        await state.finish()

        return

    news_info = sorted(db.get_news_by_tags(call.from_user.id), reverse=True)

    print(news_info)

    if user_news_len[call.message.message_id] != len(news_info):
        user_news[call.message.message_id] += len(news_info) - user_news_len[call.message.message_id]
        user_news_len[call.message.message_id] = len(news_info)

    if call.data == "next":
        user_news[call.message.message_id] += 1
        counter = user_news[call.message.message_id]
        await call.message.edit_media(
            media=InputMediaPhoto(news_info[counter][5], caption=f"`{news_info[counter][2]}`\n\n"
                                                                 f"{news_info[counter][3]}\n\n"
                                                                 f"{news_info[counter][4]}", parse_mode="MARKDOWN"),
            reply_markup=to_navigate_3 if len(news_info) - 1 - counter == 0 else to_navigate_2)
    elif call.data == "prev":
        user_news[call.message.message_id] -= 1
        counter = user_news[call.message.message_id]
        await call.message.edit_media(
            media=InputMediaPhoto(news_info[counter][5], caption=f"`{news_info[counter][2]}`\n\n"
                                                                 f"{news_info[counter][3]}\n\n"
                                                                 f"{news_info[counter][4]}", parse_mode="MARKDOWN"),
            reply_markup=to_navigate_1 if counter == 0 else to_navigate_2)


# ---------------------------
# Создание новости
# ---------------------------

@dp.message_handler(text="Написать новость")
async def create_news(message: Message, state: FSMContext):
    if not db.get_user_type(message.from_user.id):
        await message.answer("Введите заголовок Вашей новости!", reply_markup=ReplyKeyboardRemove())

        await News.title.set()


@dp.message_handler(state=News.title)
async def news_title(message: Message, state: FSMContext):
    await state.update_data({"title": message.text})

    await message.answer("Напишите текст новости!")

    await News.next()


@dp.message_handler(state=News.text)
async def news_text(message: Message, state: FSMContext):
    await state.update_data({"text": message.text})

    await message.answer("Пришлите изображение для новости!")

    await News.next()


@dp.message_handler(state=News.image, content_types=['photo'])
async def news_image(message: Message, state: FSMContext):
    await state.update_data({"image": message.photo[-1].file_id})

    await message.answer("Выберите под какие темы подходит эта новость!",
                         reply_markup=generate_choose_theme_keyboard(message.from_user.id))
    user_info[message.from_user.id] = []

    await News.next()


@dp.message_handler(state=News.image, content_types=['document', 'text'])
async def news_not_image(message: Message, state: FSMContext):
    await message.answer("Нужно отправить фотографию" + ", а не файл" if message.content_type == "document" else "!")


@dp.callback_query_handler(state=News.sure)
async def news_sure(call: CallbackQuery, state: FSMContext):
    await call.message.delete()
    if call.data == "yes":
        data = await state.get_data()
        db.add_news(call.from_user.id, data['title'], data['text'], data['image'], data['themes'])

        await call.message.answer("Новость успешно добавлена!", reply_markup=teacher_keyboard)

        await state.finish()
    else:
        await call.message.answer("Что изменить?", reply_markup=InlineKeyboardMarkup().
                                  add(InlineKeyboardButton(text="Заголовок", callback_data="title")).
                                  add(InlineKeyboardButton(text="Текст", callback_data="text")).
                                  add(InlineKeyboardButton(text="Изображение", callback_data="image")).
                                  add(InlineKeyboardButton(text="Темы", callback_data="themes")))

        await News.edit.set()


@dp.callback_query_handler(state=News.edit)
async def news_edit(call: CallbackQuery, state: FSMContext):
    await state.update_data({"to_update": call.data})

    await call.message.delete()

    if call.data == "image":
        await call.message.answer("Пришлите новое изображение!")

        await News.edited.set()

        return

    if call.data == "themes":
        await call.message.answer("Выберите нужные темы!",
                                  reply_markup=generate_choose_theme_keyboard(call.from_user.id))

        user_info[call.from_user.id] = []

        await News.themes.set()

        return

    await call.message.answer("Напишите новое значение!")

    await News.edited.set()


@dp.message_handler(state=News.edited, content_types=['photo', 'text'])
async def news_edited(message: Message, state: FSMContext):
    data = await state.get_data()

    if message.content_type == "photo":
        await state.update_data({data["to_update"]: message.photo[-1].file_id})

        await message.answer("Фото обновлено!")

    else:
        await state.update_data({data["to_update"]: message.text})

        await message.answer("Изменения внесены!")

    data = await state.get_data()

    await message.answer_photo(photo=data["image"], caption=f"`{data['title']}`\n\n"
                                                            f"{data['text']}\n\n"
                                                            f"{generate_tags(data['themes'])}",
                               parse_mode="MARKDOWN")

    await message.answer("Всё правильно?", reply_markup=InlineKeyboardMarkup().
                         row(InlineKeyboardButton(text="Да", callback_data="yes"),
                             InlineKeyboardButton(text="Нет", callback_data="no")))

    await News.sure.set()


# ---------------------------
# Расписание
# ---------------------------

@dp.message_handler(text="Расписание")
async def schedule_when(message: Message, state: FSMContext):
    await message.answer("Выберите какое Вам нужно расписание!",
                         reply_markup=ReplyKeyboardMarkup().row("Сегодня", "Завтра").row("На неделю"))

    await Schedule.date.set()


@dp.message_handler(state=Schedule.date)
async def schedule_date(message: Message, state: FSMContext):
    if message.text not in ["Сегодня", "Завтра", "На неделю"]:
        await message.answer("Нужно нажать на кнопку!")

        return

    if db.get_user_type(message.from_user.id):

        student_info = db.get_student_info(message.from_user.id)

        if message.text == "Сегодня":
            await message.answer(parser.today(group=student_info[5]), reply_markup=student_keyboard)

        elif message.text == "Завтра":
            await message.answer(parser.tommorow(group=student_info[5]), reply_markup=student_keyboard)

        else:
            for i in parser.on_weeek(group=student_info[5]):
                await message.answer(i, reply_markup=student_keyboard)
    else:

        teacher_info = db.get_teacher_info(message.from_user.id)

        if message.text == "Сегодня":
            await message.answer(
                parser.today(prepod=True, fio=f"{teacher_info[1]} {teacher_info[2]} {teacher_info[3]}"),
                reply_markup=teacher_keyboard)
        elif message.text == "Завтра":
            await message.answer(parser.tommorow(prepod=True, fio=f"{teacher_info[1]} {teacher_info[2]} {teacher_info[3]}"),
                reply_markup=teacher_keyboard)
        else:
            for i in parser.on_weeek(prepod=True, fio=f"{teacher_info[1]} {teacher_info[2]} {teacher_info[3]}"):
                await message.answer(i, reply_markup=teacher_keyboard)

    await state.finish()


# ---------------------------
# Регистрация
# ---------------------------

@dp.message_handler(state=Choose.get_type)
async def get_user_type(message: Message, state: FSMContext):
    if message.text == "Преподаватель":
        await message.answer("Напишите Ваше Фио", reply_markup=ReplyKeyboardRemove())

        await TeacherRegistration.fio.set()
        return

    if message.text == "Студент":
        await message.answer("Напишите Ваше ФИО", reply_markup=ReplyKeyboardRemove())

        await StudentRegistration.fio.set()
        return

    await message.answer("Нужно нажать на кнопку ниже!")


# ---------------------------
# Регистрация студента
# ---------------------------

@dp.message_handler(state=StudentRegistration.fio)
async def get_student_fio(message: Message, state: FSMContext):
    if not message.text.replace(" ", "").isalpha():
        await message.answer("⛔ ФИО не должно содержать цифр!")

        return

    if len(message.text.split()) != 3:
        await message.answer("⛔ Нужно ввести фамилию, имя и отчество через пробел!")

        return

    await state.update_data({"fio": message.text})
    await message.answer("Напишите Вашу группу")

    await StudentRegistration.next()


@dp.message_handler(state=StudentRegistration.group)
async def get_student_group(message: Message, state: FSMContext):
    await state.update_data({"group": message.text})

    await message.answer("Напишите Ваш студенческий билет")

    await StudentRegistration.next()


@dp.message_handler(state=StudentRegistration.stud_bilet)
async def get_stud_bilet(message: Message, state: FSMContext):
    if not message.text.isdigit():
        await message.answer("⛔ Нужно ввести только цифры студенческого билета!")

        return

    if len(message.text) != 6:
        await message.answer("⛔ Студенческий билет содержит 6 цифр!")

        return

    await state.update_data({"stud_bilet": message.text})

    await message.answer("Выберите интересующие Вас темы!", reply_markup=generate_choose_theme_keyboard(
        message.from_user.id))

    user_info[message.from_user.id] = []

    await StudentRegistration.next()


# ---------------------------
# Регистрация Преподавателя
# ---------------------------

@dp.message_handler(state=TeacherRegistration.fio)
async def get_teacher_fio(message: Message, state: FSMContext):
    if not message.text.replace(" ", "").isalpha():
        await message.answer("⛔ ФИО не должно содержать цифр!")

        return

    if len(message.text.split()) != 3:
        await message.answer("⛔ Нужно ввести фамилию, имя и отчество через пробел!")

        return

    await state.update_data({"fio": message.text})

    await message.answer("Выберите интересующие Вас темы!", reply_markup=generate_choose_theme_keyboard(
        message.from_user.id))

    user_info[message.from_user.id] = []

    await TeacherRegistration.next()


# ---------------------------
# Выбор тем для новостей
# ---------------------------

@dp.callback_query_handler(state=StudentRegistration.themes)
@dp.callback_query_handler(state=TeacherRegistration.themes)
@dp.callback_query_handler(state=News.themes)
async def get_student_themes(call: CallbackQuery, state: FSMContext):
    state_generator = await state.get_state()
    state_name = state_generator.split(":")[0]
    if call.data == "themes_end":

        if len(user_info[call.from_user.id]) == 0:
            await call.answer(show_alert=True, text="Нужно выбрать хотя бы одну тему")

            return

        await call.message.delete()

        await state.update_data({"themes": user_info[call.from_user.id]})

        data = await state.get_data()

        if state_name == "News":
            await call.message.answer_photo(photo=data["image"], caption=f"`{data['title']}`\n\n"
                                                                         f"{data['text']}\n\n"
                                                                         f"{', '.join(data['themes'])}",
                                            parse_mode="MARKDOWN")

            await call.message.answer("Всё правильно?", reply_markup=InlineKeyboardMarkup().
                                      row(InlineKeyboardButton(text="Да", callback_data="yes"),
                                          InlineKeyboardButton(text="Нет", callback_data="no")))

            await News.next()

            del user_info[call.from_user.id]

            return

        if state_name == "StudentRegistration":
            db.add_student(stud_id=call.from_user.id, fio=data["fio"], stud_bilet=data["stud_bilet"],
                           stud_group=data["group"], themes=data["themes"])
        elif state_name == "TeacherRegistration":
            db.add_teacher(teacher_id=call.from_user.id, fio=data["fio"], themes=data["themes"])

        await call.message.answer("Регистрация завершена!", reply_markup=
        student_keyboard if db.get_user_type(call.from_user.id) else teacher_keyboard)

        await state.finish()

        del user_info[call.from_user.id]

        return

    theme = call.data.split("_")[1]

    if theme not in user_info[call.from_user.id]:
        user_info[call.from_user.id].append(theme)

    else:
        user_info[call.from_user.id].remove(theme)

    await call.message.edit_reply_markup(generate_choose_theme_keyboard(call.from_user.id))


async def main():
    await dp.start_polling(bot)


if __name__ == '__main__':
    asyncio.run(main())
