from typing import Any

import psycopg2

from DataBase.Config import host, user, password, datab


class DB:

    def __init__(self):
        self.connection = psycopg2.connect(
            host=host,
            user=user,
            password=password,
            database=datab
        )

        self.connection.autocommit = True

        self.cursor = self.connection.cursor()

        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS student(
            id serial PRIMARY KEY,
            first_name varchar(50),
            last_name varchar(50),
            mid_name varchar(50),
            stud_bilet INTEGER,
            stud_group varchar(10)
        )
        """)

        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS teacher(
            id serial PRIMARY KEY,
            first_name varchar(50),
            last_name varchar(50),
            mid_name varchar(50)
        )
        """)

        self.cursor.execute("""
                CREATE TABLE IF NOT EXISTS themes(
                    id serial PRIMARY KEY,
                    theme_name varchar(50),
                    student_id INTEGER REFERENCES student(id),
                    teacher_id INTEGER REFERENCES teacher(id)
                )
                """)

        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS user_types(
            id serial PRIMARY KEY,
            is_student bool
        )
        """)

        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS news(
            id serial PRIMARY KEY,
            author_id INTEGER,
            title varchar(50),
            text varchar(500),
            themes varchar(500),
            image varchar(100)
        )
        """)

        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS vkr(
            id serial PRIMARY KEY,
            teacher_id INTEGER REFERENCES teacher(id),
            student_id INTEGER REFERENCES student(id),
            theme varchar(100)
        )
        """)

        self.cursor.execute("""
                CREATE TABLE IF NOT EXISTS curswork(
                    id serial PRIMARY KEY,
                    teacher_id INTEGER REFERENCES teacher(id),
                    student_id INTEGER REFERENCES student(id),
                    theme varchar(100)
                )
                """)

    def add_student(self, stud_id: int, fio: str, stud_bilet: int, stud_group: str, themes: list) -> None:
        self.cursor.execute(f"""
        INSERT INTO student(id, first_name, last_name, mid_name, stud_bilet, stud_group) VALUES 
        ({stud_id}, '{fio.split()[0]}', '{fio.split()[1]}', '{fio.split()[2]}', {stud_bilet}, '{stud_group}')
        """)

        for i in themes:
            self.cursor.execute(f"""
            INSERT INTO themes(theme_name, student_id) VALUES 
            ('{i}', {stud_id})
            """)

        self.cursor.execute(f"""
        INSERT INTO user_types(id, is_student) VALUES 
        ({stud_id}, True)
        """)

    def add_teacher(self, teacher_id: int, fio: str, themes: list) -> None:
        self.cursor.execute(f"""
        INSERT INTO teacher(id, first_name, last_name, mid_name) VALUES 
        ({teacher_id}, '{fio.split()[0]}', '{fio.split()[1]}', '{fio.split()[2]}')
        """)

        for i in themes:
            self.cursor.execute(f"""
            INSERT INTO themes(theme_name, teacher_id) VALUES 
            ('{i}', {teacher_id})
            """)

        self.cursor.execute(f"""
        INSERT INTO user_types(id, is_student) VALUES 
        ({teacher_id}, FALSE)
        """)

    def check_user(self, stud_id: int) -> bool:
        self.cursor.execute(f"""
        SELECT * FROM user_types WHERE id = {stud_id}
        """)

        return True if self.cursor.fetchone() is not None else False

    def get_user_type(self, stud_id: int) -> bool:
        self.cursor.execute(f"""
        SELECT is_student FROM user_types WHERE id = {stud_id}
        """)

        return self.cursor.fetchone()[0]

    def get_student_info(self, stud_id: int) -> tuple[Any, ...] | None:
        self.cursor.execute(f"""
        SELECT * FROM student WHERE id = {stud_id}
        """)

        return self.cursor.fetchone()

    def get_teacher_info(self, teacher_id: int) -> tuple[Any, ...] | None:
        self.cursor.execute(f"""
        SELECT * FROM teacher WHERE id = {teacher_id}
        """)

        return self.cursor.fetchone()

    def add_news(self, teacher_id: int, title: str, text: str, image: str, tags: list) -> None:
        str_tags = ",".join(tags)

        self.cursor.execute(f"""
        INSERT INTO news(author_id, title, text, image, themes) VALUES 
        ({teacher_id}, '{title}', '{text}', '{image}', '{str_tags}')
        """)

    def get_news_by_tags(self, user_id):
        self.cursor.execute(f"""
        SELECT * FROM news
        """)

        new = self.cursor.fetchall()

        print(new)

        if self.get_user_type(user_id):
            self.cursor.execute(f"""
            SELECT theme_name FROM themes WHERE student_id = {user_id}
            """)
        else:
            self.cursor.execute(f"""
                        SELECT theme_name FROM themes WHERE teacher_id = {user_id}
                        """)

        themes = [item for sublist in self.cursor.fetchall() for item in sublist]

        result = []

        for n in new:
            for theme in themes:
                if theme in n[4].split(","):
                    result.append(list(n))
                    break

        return result

    def add_vkr(self, teacher_id: int, theme: str) -> None:
        self.cursor.execute(f"""
        INSERT INTO vkr(teacher_id, theme) VALUES 
        ({teacher_id}, '{theme}')
        """)

    def set_vkr(self, student_id: int, theme: str) -> None:
        self.cursor.execute(f"""
        UPDATE vkr SET student_id={student_id} WHERE theme = '{theme}'
        """)

        self.cursor.execute(f"""
                SELECT teacher_id FROM vkr WHERE student_id={student_id}
                """)

        return self.cursor.fetchone()[0]

    def get_vkr_by_teacher_id(self, teacher_id):
        self.cursor.execute(f"""
        SELECT theme, student_id FROM vkr WHERE teacher_id = {teacher_id}
        """)

        return list(self.cursor.fetchall())

    def get_curs_by_teacher_id(self, teacher_id):
        self.cursor.execute(f"""
        SELECT theme, student_id FROM curswork WHERE teacher_id = {teacher_id}
        """)

        return list(self.cursor.fetchall())

    def add_curs(self, teacher_id: int, theme: str) -> None:
        self.cursor.execute(f"""
        INSERT INTO curswork(teacher_id, theme) VALUES 
        ({teacher_id}, '{theme}')
        """)

    def set_curs(self, student_id: int, theme: str) -> None:
        self.cursor.execute(f"""
        UPDATE curswork SET student_id={student_id} WHERE theme = '{theme}'
        """)

        self.cursor.execute(f"""
        SELECT teacher_id FROM curswork WHERE student_id={student_id}
        """)

        return self.cursor.fetchone()[0]

    def get_curs_by_teacher_id(self, teacher_id):
        self.cursor.execute(f"""
        SELECT theme, student_id FROM curswork WHERE teacher_id = {teacher_id}
        """)

        return list(self.cursor.fetchall())

    def get_all_teachers(self):
        self.cursor.execute(f"""
        SELECT last_name, first_name, mid_name, id FROM teacher
        """)

        return self.cursor.fetchall()

    def check_has_vkr(self, student_id):
        self.cursor.execute(f"""
        SELECT * FROM vkr WHERE student_id = {student_id}
        """)

        return True if self.cursor.fetchone() is not None else False

    def check_has_curs(self, student_id):
        self.cursor.execute(f"""
        SELECT * FROM curswork WHERE student_id = {student_id}
        """)

        return True if self.cursor.fetchone() is not None else False