host = 'localhost'
user = 'postgres'
password = 'arsenalr2d2'
datab = 'news'