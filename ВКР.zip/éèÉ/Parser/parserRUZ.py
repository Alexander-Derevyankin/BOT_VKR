import datetime

import requests


class RuzParser:

    def __init__(self):
        self.url = 'https://ruz.fa.ru/api/search'

    def today(self, group="Вас", prepod=False, fio=None) -> str:
        today_date = str(datetime.date.today()).replace('-', '.')

        if not prepod:
            try:
                group_id = requests.get(self.url,
                                        params={"term": group,
                                                "type": "group"
                                                }
                                        ).json()[0]['id']
            except IndexError:
                return "Нет такой группы"

            response_work_today = requests.get(f'https://ruz.fa.ru/api/schedule/group/{group_id}',
                                               params={"start": today_date,
                                                       "finish": today_date
                                                       }
                                               ).json()
        else:
            response = requests.get(self.url,
                                    params={"term": fio,
                                            "type": "person"
                                            }
                                    ).json()
            try:
                pers_id = response[0]['id']
            except IndexError:
                return "Такой преподаватель не найден" if prepod else "Такой группы не найдено"

            response_work_today = requests.get(f"https://ruz.fa.ru/api/schedule/person/{pers_id}",
                                               params={"start": today_date,
                                                       "finish": today_date
                                                       }
                                               ).json()

        result = ""

        for i in response_work_today:
            if i['group'] is not None:
                result += ('Преподаватель: ' + i['lecturer'] + '\n' +
                           'Дата: ' + i['date'] + ' ' + i['dayOfWeekString'] + '\n' +
                           'Время: ' + i['beginLesson'] + '-' + i['endLesson'] + '\n' +
                           'Дисциплина: ' + i['discipline'] + '\n' +
                           'Вид занятия: ' + i['kindOfWork'] + '\n' +
                           'Аудитория: ' + i['auditorium'] + ' (' + i['building'] + ')\n' +
                           'Учебная группа: ' + i['group'] + '\n' +
                           '--------------------------\n')

            elif i['stream'] is not None:

                result += ('Преподаватель: ' + i['lecturer'] + '\n' +
                           'Дата: ' + i['date'] + ' ' +
                           i['dayOfWeekString'] + '\n' +
                           'Время: ' + i['beginLesson'] + ' - ' +
                           i['endLesson'] + '\n' +
                           'Дисциплина: ' + i['discipline'] + '\n' +
                           'Вид занятия: ' + i['kindOfWork'] + '\n' +
                           'Аудитория: ' + i['auditorium'] + ' (' +
                           i['building'] + ')' + '\n' +
                           'Поток: ' + i['stream'] + '\n' +
                           '--------------------------\n')

        if not response_work_today:
            result += (f'У {group} сегодня нет пар')

        return result

    def tommorow(self, group="Вас", prepod=False, fio=None) -> str:
        today_date = str(datetime.date.today() + datetime.timedelta(days=1)).replace('-', '.')

        if not prepod:
            try:
                group_id = requests.get(self.url,
                                        params={"term": group,
                                                "type": "group"
                                                }
                                        ).json()[0]['id']
            except IndexError:
                return "Нет такой группы"

            response_work_today = requests.get(f'https://ruz.fa.ru/api/schedule/group/{group_id}',
                                               params={"start": today_date,
                                                       "finish": today_date
                                                       }
                                               ).json()
        else:
            response = requests.get(self.url,
                                    params={"term": fio,
                                            "type": "person"
                                            }
                                    ).json()
            try:
                pers_id = response[0]['id']
            except IndexError:
                return "Такой преподаватель не найден" if prepod else "Такой группы не найдено"

            response_work_today = requests.get(f"https://ruz.fa.ru/api/schedule/person/{pers_id}",
                                               params={"start": today_date,
                                                       "finish": today_date
                                                       }
                                               ).json()

        result = ""

        for i in response_work_today:
            if i['group'] is not None:
                result += ('Преподаватель: ' + i['lecturer'] + '\n' +
                           'Дата: ' + i['date'] + ' ' + i['dayOfWeekString'] + '\n' +
                           'Время: ' + i['beginLesson'] + '-' + i['endLesson'] + '\n' +
                           'Дисциплина: ' + i['discipline'] + '\n' +
                           'Вид занятия: ' + i['kindOfWork'] + '\n' +
                           'Аудитория: ' + i['auditorium'] + ' (' + i['building'] + ')\n' +
                           'Учебная группа: ' + i['group'] + '\n' +
                           '--------------------------\n')

            elif i['stream'] is not None:

                result += ('Преподаватель: ' + i['lecturer'] + '\n' +
                           'Дата: ' + i['date'] + ' ' +
                           i['dayOfWeekString'] + '\n' +
                           'Время: ' + i['beginLesson'] + ' - ' +
                           i['endLesson'] + '\n' +
                           'Дисциплина: ' + i['discipline'] + '\n' +
                           'Вид занятия: ' + i['kindOfWork'] + '\n' +
                           'Аудитория: ' + i['auditorium'] + ' (' +
                           i['building'] + ')' + '\n' +
                           'Поток: ' + i['stream'] + '\n' +
                           '--------------------------\n')

        if not response_work_today:
            result += (f'У {group} сегодня нет пар')

        return result

    def on_weeek(self, group="Вас", prepod=False, fio=None):
        if not prepod:
            try:
                group_id = requests.get(self.url,
                                        params={"term": group,
                                                "type": "group"
                                                }
                                        ).json()[0]['id']
            except:
                return ['Нет такой группы']

            response_work = requests.get(f'https://ruz.fa.ru/api/schedule/group/{group_id}',
                                         params={"start": datetime.date.today() - datetime.timedelta(
                                             days=datetime.date.today().weekday()) + datetime.timedelta(days=0),
                                                 "finish": datetime.date.today() - datetime.timedelta(
                                                     days=datetime.date.today().weekday()) + datetime.timedelta(
                                                     days=6)
                                                 }
                                         ).json()
        else:
            response = requests.get(self.url,
                                    params={"term": fio,
                                            "type": "person"
                                            }
                                    ).json()

            try:
                pers_id = response[0]['id']
            except IndexError:
                return "Такой преподаватель не найден" if prepod else "Такой группы не найдено"

            response_work = requests.get(f"https://ruz.fa.ru/api/schedule/person/{pers_id}",
                                         params={"start": datetime.date.today() - datetime.timedelta(
                                             days=datetime.date.today().weekday()) + datetime.timedelta(days=0),
                                                 "finish": datetime.date.today() - datetime.timedelta(
                                                     days=datetime.date.today().weekday()) + datetime.timedelta(
                                                     days=6)
                                                 }
                                         ).json()

        result = ""
        date = ''
        rslt = []

        for i in response_work:
            if i['date'] != date:
                if result != "":
                    rslt.append(result)
                    result = ""
                date = i['date']

            if i['group'] is not None:
                result += ('Преподаватель: ' + i['lecturer'] + '\n' +
                           'Дата: ' + i['date'] + ' ' + i['dayOfWeekString'] + '\n' +
                           'Время: ' + i['beginLesson'] + '-' + i['endLesson'] + '\n' +
                           'Дисциплина: ' + i['discipline'] + '\n' +
                           'Вид занятия: ' + i['kindOfWork'] + '\n' +
                           'Аудитория: ' + i['auditorium'] + ' (' + i['building'] + ')\n' +
                           'Учебная группа: ' + i['group'] + '\n' +
                           '--------------------------\n')

            elif i['stream'] is not None:

                result += ('Преподаватель: ' + i['lecturer'] + '\n' +
                           'Дата: ' + i['date'] + ' ' +
                           i['dayOfWeekString'] + '\n' +
                           'Время: ' + i['beginLesson'] + ' - ' +
                           i['endLesson'] + '\n' +
                           'Дисциплина: ' + i['discipline'] + '\n' +
                           'Вид занятия: ' + i['kindOfWork'] + '\n' +
                           'Аудитория: ' + i['auditorium'] + ' (' +
                           i['building'] + ')' + '\n' +
                           'Поток: ' + i['stream'] + '\n' +
                           '--------------------------\n')

        if result != "":
            rslt.append(result)

        if not response_work:
            rslt.append(f'У {group} на этой неделе нет пар')

        return rslt
